var btnB = document.getElementsByClassName('pop-up-b');
var popUp = document.getElementsByClassName('pop-up')[0];
var close = document.getElementsByClassName('close')[0];
var open = document.getElementsByClassName('btn-open')[0];
var nav = document.getElementsByClassName('header__top')[0];


open.onclick = function(){
  if(nav.classList.contains("active")){
    nav.classList.remove("active");
    this.getElementsByTagName('img')[0].setAttribute("src", "images/open.png");
  }
  else {
    this.getElementsByTagName('img')[0].setAttribute("src", "images/close.png");
    nav.classList.add("active");
  }
};

close.onclick = function(){
  butt = this;
  show(butt);
};


for(var i = 0; i < btnB.length; i++) {
      var anchor = btnB[i];
      anchor.onclick = function() {
          show();
      }
  }
  
function show(){
  console.log(popUp);
  if(popUp.style.display == "block"){
    popUp.style.display = "none";
  }
  else{
    popUp.style.display = "block";
  }
};
